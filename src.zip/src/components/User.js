import React, { Component } from "react";

class User extends Component {

    render() {

        return (
            <div>
                <div>Name is: {this.props.name}</div>
                <div>Age is: {this.props.age}</div>
                <div>Hobby is: {this.props.hobby}</div>

            </div>
        )
    }
}
export default User