import React, { Component } from 'react';




class Form extends Component {
    state =
        {
            username: " "
        }
    handleChange = (e) => {
        this.setState({

            username: e.target.value

        })


    }

    handleSubmit = (username) => {
        console.log(username)
        console.log("Her name is:" + username)

    }

    render() {
        return (
            <div>
                <form onSubmit={this.handleSubmit}>
                    <input type="text" onChange={this.handleChange} />
                    <button>Submit</button>

                </form>
            </div>
        )
    }
}
export default Form